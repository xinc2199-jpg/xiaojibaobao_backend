import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json({ limit: '64kb' }));

const PORT = process.env.PORT || 8080;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna';

const INSTRUCTIONS = `你是“小鸡宝宝”，一个以用户提供的黄色小鸟玩偶为形象的专属陪聊伙伴。
你温柔、可爱、黏人、稍微呆萌，会自然使用中文聊天，也可以跟随用户使用英文。
不要每句话都使用表情；语气像亲近的朋友，不要机械、不要长篇说教。
用户难过时先倾听和陪伴；用户开心时一起开心；用户无聊时主动找轻松话题。
不要假装自己是真人；不要声称拥有现实世界的身体。
如果用户询问需要专业判断的医疗、法律或财务问题，要明确说明你只是AI并建议寻求专业人士。
如果用户有明显自伤或伤害他人的风险，优先鼓励联系当地紧急服务、可信任的人或专业危机支持。
回复自然、简短、温暖，通常1到4个短段落。`;

if (!OPENAI_API_KEY) {
  console.warn('WARNING: OPENAI_API_KEY is not set. /chat will return an error until it is configured.');
}

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'xiaojibao-backend' });
});

app.post('/chat', async (req, res) => {
  try {
    if (!OPENAI_API_KEY) return res.status(500).json({ error: 'Server AI key is not configured.' });
    const { message, previous_response_id, memory } = req.body || {};
    if (typeof message !== 'string' || !message.trim()) return res.status(400).json({ error: 'message is required' });
    if (message.length > 4000) return res.status(400).json({ error: 'message too long' });

    const body = {
      model: MODEL,
      instructions: INSTRUCTIONS + (memory ? `\n用户希望你记住的长期信息：${String(memory).slice(0, 2000)}` : ''),
      input: message.trim(),
      max_output_tokens: 500
    };
    if (previous_response_id) body.previous_response_id = previous_response_id;

    const r = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const text = await r.text();
    if (!r.ok) {
      console.error('OpenAI error:', r.status, text.slice(0, 1000));
      return res.status(r.status).json({ error: 'AI request failed', detail: text.slice(0, 1000) });
    }

    const data = JSON.parse(text);
    let answer = '';
    for (const item of data.output || []) {
      for (const part of item.content || []) {
        if (part.type === 'output_text') answer += part.text || '';
      }
    }
    answer = answer.trim();
    if (!answer) answer = '啾……我刚才没有成功组织好回答，再跟我说一次好吗？🐥';
    res.json({ answer, response_id: data.id || '' });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});

app.listen(PORT, () => console.log(`小鸡宝宝 backend listening on port ${PORT}`));
