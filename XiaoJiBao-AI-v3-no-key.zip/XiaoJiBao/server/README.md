# 小鸡宝宝 AI 后端

这个后端负责保存 OpenAI API Key，Android App 不再保存或要求用户输入 API Key。

## 本地运行

1. 安装 Node.js 20+
2. `npm install`
3. 设置环境变量 `OPENAI_API_KEY`
4. `npm start`
5. 测试 `GET /health`

例如 Linux/macOS:
`OPENAI_API_KEY="你的Key" npm start`

Windows PowerShell:
`$env:OPENAI_API_KEY="你的Key"; npm start`

## 部署

把 `server` 文件夹部署到支持 Node.js 的服务，并在服务端环境变量中设置 `OPENAI_API_KEY`。
然后把 Android 项目里的 `BACKEND_URL` 改成你的 HTTPS 地址。

**不要把 API Key 放进 Android 项目、APK、GitHub 或聊天消息。**
