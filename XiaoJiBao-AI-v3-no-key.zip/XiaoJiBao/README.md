# 小鸡宝宝 AI v3 — 免输入 API Key

这个版本把 OpenAI API Key 从 Android App 移到了后端服务器。

## 结构

Android App → 你的 HTTPS 后端 `/chat` → OpenAI Responses API

用户在手机里**不需要输入 OpenAI API Key**。

## 先部署后端

进入 `server/`：

```bash
npm install
```

设置服务器环境变量：

```bash
OPENAI_API_KEY=你的OpenAI_API_Key
OPENAI_MODEL=gpt-5.6-luna
```

然后：

```bash
npm start
```

生产环境请使用 HTTPS。

## 连接 Android App

第一次打开 App，右上角 ⚙ → **AI 服务地址** → 填你的后端地址，例如：

`https://your-server.example.com`

这里不需要输入 OpenAI API Key。

## 安全

不要把 `OPENAI_API_KEY` 写进 Android 源码、APK、GitHub 或截图。后端服务器负责保管它。

## 重要

本项目提供的是 Android 源码 + Node.js 后端源码。要让手机真正联网聊天，需要先把后端部署到一个可访问的 HTTPS 服务。
