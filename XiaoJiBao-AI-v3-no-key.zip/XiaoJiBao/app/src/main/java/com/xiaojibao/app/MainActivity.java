package com.xiaojibao.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends Activity {
    private LinearLayout chat;
    private ScrollView scroll;
    private EditText input;
    private Button send;
    private TextView status;
    private static final String DEFAULT_BACKEND = "https://YOUR-SERVER-DOMAIN.example.com";
    private static final String DEFAULT_MODEL = "gpt-5.6-luna";
    private SharedPreferences P;

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }

    @Override public void onCreate(Bundle b){ super.onCreate(b); P=getSharedPreferences("xiaojibao",MODE_PRIVATE); ensureDeviceId(); build(); }
    void ensureDeviceId(){ if(P.getString("device_id","").isEmpty()) P.edit().putString("device_id", UUID.randomUUID().toString()).apply(); }
    String backend(){ return P.getString("backend_url",DEFAULT_BACKEND).replaceAll("/+$",""); }

    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(255,249,232));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(12),dp(8),dp(8),dp(8)); top.setBackgroundColor(Color.rgb(247,214,92));
        ImageView avatar=new ImageView(this); avatar.setImageResource(R.drawable.xiao_ji_bao); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(bg(Color.WHITE,50)); avatar.setClipToOutline(true); top.addView(avatar,new LinearLayout.LayoutParams(dp(50),dp(50)));
        LinearLayout title=new LinearLayout(this); title.setOrientation(LinearLayout.VERTICAL); title.setPadding(dp(12),0,0,0);
        TextView name=tv("小鸡宝宝",20,Color.rgb(74,64,53)); name.setTypeface(null,1); title.addView(name);
        status=tv(backend().contains("YOUR-SERVER")?"等待连接 AI":"AI 服务已设置 🐥",13,Color.rgb(100,85,55)); title.addView(status); top.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button settings=new Button(this); settings.setText("⚙"); settings.setTextSize(20); settings.setAllCaps(false); settings.setTextColor(Color.rgb(74,64,53)); settings.setBackgroundColor(Color.TRANSPARENT); settings.setOnClickListener(v->showSettings()); top.addView(settings,new LinearLayout.LayoutParams(dp(52),dp(52))); root.addView(top);

        scroll=new ScrollView(this); chat=new LinearLayout(this); chat.setOrientation(LinearLayout.VERTICAL); chat.setPadding(dp(12),dp(16),dp(12),dp(16)); scroll.addView(chat); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        addBubble("啾～🐥💛 我是小鸡宝宝！\n以后不用输入 API Key，我会通过 AI 服务陪你聊天。",false);

        LinearLayout bar=new LinearLayout(this); bar.setPadding(dp(10),dp(8),dp(10),dp(8)); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(Color.WHITE);
        input=new EditText(this); input.setHint("跟小鸡宝宝说说话…"); input.setTextSize(16); input.setSingleLine(true); input.setPadding(dp(14),0,dp(14),0); input.setBackground(bg(Color.rgb(255,249,232),30)); bar.addView(input,new LinearLayout.LayoutParams(0,dp(48),1));
        send=new Button(this); send.setText("发送"); send.setTextColor(Color.WHITE); send.setTextSize(15); send.setAllCaps(false); send.setBackground(bg(Color.rgb(242,165,43),30)); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(76),dp(48)); sp.setMargins(dp(8),0,0,0); bar.addView(send,sp);
        send.setOnClickListener(v->sendMessage()); input.setOnEditorActionListener((v,a,e)->{sendMessage(); return true;}); root.addView(bar); setContentView(root);
    }

    void addBubble(String s,boolean user){
        LinearLayout row=new LinearLayout(this); row.setGravity(user?Gravity.RIGHT:Gravity.LEFT); row.setPadding(dp(4),dp(5),dp(4),dp(5));
        TextView b=tv(s,16,Color.rgb(74,64,53)); b.setTextIsSelectable(true); b.setPadding(dp(14),dp(10),dp(14),dp(10)); b.setBackground(bg(user?Color.rgb(255,224,125):Color.WHITE,20)); row.addView(b,new LinearLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*0.82f),-2)); chat.addView(row); scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    }

    void sendMessage(){
        String s=input.getText().toString().trim(); if(s.isEmpty()) return;
        if(backend().contains("YOUR-SERVER")){ addBubble("小鸡宝宝还没有设置 AI 服务地址哦～🐥\n点右上角 ⚙，填入你的后端 HTTPS 地址即可。",false); return; }
        addBubble(s,true); input.setText(""); ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        send.setEnabled(false); send.setText("…"); status.setText("小鸡宝宝正在想你说的话…"); new Thread(()->callBackend(s)).start();
    }

    void callBackend(String userText){
        HttpURLConnection c=null;
        try{
            URL u=new URL(backend()+"/chat"); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json");
            JSONObject body=new JSONObject(); body.put("message",userText); body.put("device_id",P.getString("device_id","")); body.put("memory",P.getString("memory","")); String prev=P.getString("previous_response_id",""); if(!prev.isEmpty()) body.put("previous_response_id",prev);
            byte[] data=body.toString().getBytes(StandardCharsets.UTF_8); c.getOutputStream().write(data); c.getOutputStream().close();
            int code=c.getResponseCode(); InputStream is=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String resp=readAll(is); if(code<200||code>=300) throw new Exception("服务器 " + code + ": " + resp);
            JSONObject obj=new JSONObject(resp); String id=obj.optString("response_id",""); if(!id.isEmpty()) P.edit().putString("previous_response_id",id).apply(); String answer=obj.optString("answer",""); if(answer.isEmpty()) answer="啾……我刚才没有成功组织好回答，再跟我说一次好吗？🐥";
            runOnUiThread(()->{ addBubble(answer,false); send.setEnabled(true); send.setText("发送"); status.setText("AI 已连接 🐥"); });
        }catch(Exception e){ final String m=e.getMessage()==null?"连接失败":e.getMessage(); runOnUiThread(()->{ addBubble("呜……刚才连接 AI 时出了点问题。🐥\n\n"+friendlyError(m),false); send.setEnabled(true); send.setText("发送"); status.setText("AI 连接失败"); }); }
        finally{ if(c!=null)c.disconnect(); }
    }

    String readAll(InputStream is)throws Exception{ if(is==null)return ""; BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder s=new StringBuilder(); String line; while((line=r.readLine())!=null)s.append(line); return s.toString(); }
    String friendlyError(String e){ if(e.contains("401"))return "服务器的 AI 配置可能有问题，请联系 App 管理者。"; if(e.contains("429"))return "AI 服务暂时繁忙，请稍后再试。"; if(e.contains("timeout"))return "网络等待太久了，请检查手机网络后再试。"; if(e.contains("YOUR-SERVER"))return "还没有设置后端地址。"; return "请检查网络或 AI 服务地址，然后再试一次。"; }

    void showSettings(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(8),0,dp(8),0);
        EditText url=new EditText(this); url.setHint("https://你的后端地址"); url.setSingleLine(true); url.setText(P.getString("backend_url",DEFAULT_BACKEND)); box.addView(url);
        EditText memory=new EditText(this); memory.setHint("想让小鸡宝宝记住的事情（可选）"); memory.setMinLines(3); memory.setGravity(Gravity.TOP); memory.setText(P.getString("memory","")); box.addView(memory);
        TextView note=tv("这里不需要输入 OpenAI API Key。Key 只保存在 AI 后端服务器的环境变量里，App 不会保存它。\n\n当前默认模型："+DEFAULT_MODEL,12,Color.DKGRAY); note.setPadding(0,dp(10),0,0); box.addView(note);
        new AlertDialog.Builder(this).setTitle("小鸡宝宝 AI 设置").setView(box).setPositiveButton("保存",(d,w)->{ P.edit().putString("backend_url",url.getText().toString().trim()).putString("memory",memory.getText().toString().trim()).apply(); status.setText(url.getText().toString().contains("YOUR-SERVER")?"等待连接 AI":"AI 服务已设置 🐥"); }).setNeutralButton("清除聊天记忆",(d,w)->{P.edit().remove("previous_response_id").apply(); Toast.makeText(this,"已清除 AI 对话上下文",Toast.LENGTH_SHORT).show();}).setNegativeButton("取消",null).show();
    }
}
